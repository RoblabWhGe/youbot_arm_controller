
#ifndef __ORO_ARCH_POWERPC__
#define __ORO_ARCH_POWERPC__

#include "oro_atomic.h"
#include "oro_system.h"

#endif /* __ORO_ARCH_POWERPC__ */
